const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const path = require("path");
const bcrypt = require("bcrypt");
const bcryptjs = require("bcryptjs");
const jwt = require("jsonwebtoken");
const secretKey = "cica";

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

// Adatbázis kapcsolat
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "cattalodge"
});

db.connect(err => {
    if (err) {
        console.error("Hiba az adatbázishoz kapcsolódáskor:", err);
        return;
    }
    console.log("Sikeres adatbázis kapcsolat!");
});

// Regisztráció végpont
app.post("/register", async (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    db.query(sql, [name, email, hashedPassword], (err, result) => {
        if (err) {
            res.status(500).send("Hiba a regisztráció során.");
            return;
        }
        res.send("Sikeres regisztráció!");
    });
});

// Bejelentkezés végpont
app.post("/login", (req, res) => {
    const { email, password } = req.body;
    const sql = "SELECT * FROM users WHERE email = ?";
    
    db.query(sql, [email], async (err, results) => {
        if (err || results.length === 0) {
            res.status(401).send("Hibás email vagy jelszó!");
            return;
        }
        
        const user = results[0];
        const validPassword = await bcrypt.compare(password, user.password);

        if(!validPassword){
            res.status(401).send("Hibás email vagy jelszó!");
            return;
        }

        const token = jwt.sign({ userId: user.id, email: user.emails }, secretKey, { expiresIn: "1h" });
        res.json({ message: "Sikeres bejelentkezés!", token });
    });
});

app.get("/", (req, res) => {
    res.send("Szerver sikeresen fut!");
})

app.get("/cats", (req, res) => {
    const sql = "SELECT * FROM cats";
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send("Hiba a macskák lekérésekor.");
            return;
        }
        res.json(results);
    });
});

// Macskás végpont
app.post("/cats", (req, res) => {
    const { name, description, image_url, gender } = req.body;

    console.log("Fogadott gender érték:", gender); // Debugging

    if (!gender) {
        res.status(400).send("Hiba: Nem lett nem kiválasztva!");
        return;
    }

    const genderValue = gender.trim().toLowerCase();
    console.log("Mentendő gender érték:", genderValue);

    const sql = "INSERT INTO cats (name, description, image_url, gender) VALUES (?, ?, ?, ?)";
    
    db.query(sql, [name, description, image_url, genderValue], (err, result) => {
        if (err) {
            console.error("Hiba a DB mentésnél:", err);
            res.status(500).send("Hiba a macska hozzáadásakor.");
            return;
        }
        res.send("Macska sikeresen hozzáadva!");
    });
});

app.delete("/cats/:id", (req, res) => {
    const { id } = req.params;
    const sql = "DELETE FROM cats WHERE id = ?";

    db.query(sql, [id], (err, result) => {
        if (err) {
            res.status(500).send("Hiba a macska törlésekor.")
        }
        res.send("Macska sikeresen törölve!");
    });
});

// Foglalás végpont
app.post("/book", (req, res) => {
    const { week, userId } = req.body;
    console.log("Foglalási kérés érkezett:", req.body); // Kimenet ellenőrzés

    const checkSql = "SELECT * FROM bookings WHERE week = ?";
    const insertSql = "INSERT INTO bookings (week, user_id) VALUES (?, ?)";

    db.query(checkSql, [week], (err, results) => {
        if (err) {
            console.error("Adatbázis hiba (ellenőrzés):", err);
            res.status(500).send("Hiba a foglalás ellenőrzése során.");
            return;
        }
        if (results.length > 0) {
            res.status(400).send("Ez az időpont már foglalt!");
        } else {
            db.query(insertSql, [week, userId], (err, result) => {
                if (err) {
                    console.error("Adatbázis hiba (beszúrás):", err);
                    res.status(500).send("Hiba a foglalás rögzítése során.");
                    return;
                }
                res.send("Foglalás sikeres!");
            });
        }
    });
});

app.get("/bookings/:userId", async (req, res) => {
    const userId = req.params.userId;
    const sql = "SELECT week FROM bookings WHERE user_id = ?";

    db.query(sql, [userId], (err, results) => {
        if (err) {
            res.status(500).send("Hiba a foglalások lekérésekor.");
            return;
        }
        res.json(results);
    });
});

// Felhasználó végpont
app.get("/users/:userId", async (req, res) => {
    const { userId } = req.params;
    const sql = "SELECT name, email FROM users WHERE id = ?";

    db.query(sql, [userId], (err, results) => {
        if (err) {
            res.status(500).send("Hiba a felhasználói adatok lekérésekor.");
            return;
        }
        if (results.length > 0) {
            res.json(results[0]);
        } else{
            res.status(404).send("Felhasználó nem található.");
        }
    });
});

app.put("/users/:userId", (req, res) => {
    const { userId } = req.params;
    const { name, email } = req.body;
    const sql = "UPDATE users SET name = ?, email = ? WHERE id = ?";

    db.query(sql, [name, email, userId], (err, result) => {
        if (err){
            res.status(500).send("Hiba a felhasználói adatok frissítésekor.");
            return;
        }
        res.send("Felhasználói adatok sikeresen módosítva!");
    })
})

app.listen(port, () => {
    console.log(`Szerver fut: http://localhost:${port}`);
});