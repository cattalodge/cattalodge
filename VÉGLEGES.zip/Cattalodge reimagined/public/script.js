import { getUserIdFromToken  } from "./auth.js";

document.addEventListener("DOMContentLoaded", async () => {
    const bookButton = document.getElementById("bookNow");
    const weeksContainer = document.getElementById("weeks-container");
    const catsContainer = document.getElementById("cats-container");
    const addCatForm = document.getElementById("add-cat-form");
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");
    const catImage = document.getElementById("cat-image");
    const userId = getUserIdFromToken();
    if (userId) {
        loadBookings(userId);
        loadUserProfile(userId);
    }

/* A hét macskája kép váltogazás */
        let images = [
            "https://files.catbox.moe/2s6opm.jpg",
            "https://files.catbox.moe/pmcdyc.jpg"
        ];
        let index = 0;
        setInterval(() => {
            catImage.style.opacity = 0; // Elhalványítás
            setTimeout(() => {
                index = (index + 1) % images.length;
                catImage.src = images[index]; // Kép váltása
                catImage.style.opacity = 1; // Új kép megjelenítése
            }, 1000); // 1 másodperc után vált a kép
        }, 4000); // 4 másodpercenként vált

    /* Macskák nemének a kiválasztása */
    addCatForm?.addEventListener("submit", async (event) => {
        event.preventDefault();

        const name = document.getElementById("cat-name").value;
        const description = document.getElementById("cat-description").value;
        const image_url = document.getElementById("cat-picture").value;
        const genderElem = document.getElementById("cat-gender");
        const gender = genderElem ? genderElem.value.trim().toLowerCase() : "";

        if (!gender){
            alert("Kérlek, válassz nemet!");
            return;
        }

        console.log("Beküldött gender érték: ", gender);

        const response = await fetch("http://localhost:3000/cats", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, description, image_url, gender: gender.trim() })
        });

        const data = await response.text();
        alert(data);
        loadCats();
    });

    /* Foglalj most, regisztrálások, kijelentkezések és bejelentkezések kezelése */
    document.getElementById("bookNow")?.addEventListener("click", () => {
        const token = localStorage.getItem("authToken");
        const loginLink = document.getElementById("login-link");
        const registerLink = document.getElementById("register-link");
        const logoutLink = document.getElementById("logout-link");
        
        if (token){
            loginLink.style.display = "none";
            registerLink.style.display = "none";
            logoutLink.style.display = "block";
        }else{
            loginLink.style.display = "block";
            registerLink.style.display = "block";
            logoutLink.style.display = "none";
        }
        
        if (!token) {
            alert("Foglaláshoz előbb be kell jelentkezned!");
            window.location.href = "login.html";
            return;
        }
        
        const selectedWeek = prompt("Melyik hétre szeretnél foglalni? (1-52)");
        
        if (selectedWeek) {
            bookWeek(parseInt(selectedWeek), userId);
        }
    });

        function getUserIdFromToken() {
            const token = localStorage.getItem("authToken");
            if (!token) return null;
        
            const payload = JSON.parse(atob(token.split(".")[1])); // Dekódoljuk a JWT tokent
            return payload.userId; // Visszaadja az ID-t
        }

if (window.location.pathname.includes("admin.html")) {
    const token = localStorage.getItem("authToken");
    const isAdmin = localStorage.getItem("isAdmin");
    if (!token) {
        alert("Admin oldal eléréséhez be kell jelentkezned!");
        window.location.href = "index.html";
        return;
    }
    if (isAdmin !== "true") {
        alert("Nincs jogosultságod az admin oldalhoz!");
        window.location.href = "index.html";
    }
}

    // Bejelentkezési eseménykezelő
    loginForm?.addEventListener("submit", async (event) => {
        event.preventDefault();

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        const response = await fetch("http://localhost:3000/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();
        if (data.token) {
            localStorage.setItem("authToken", data.token);

            if (email === "admin@gmail.com") {
                localStorage.setItem("isAdmin", "true");
            } else {
                localStorage.setItem("isAdmin", "false");
            }

            alert("Sikeres bejelentkezés!");
            window.location.href = "index.html";
        } else {
            alert("Hibás email vagy jelszó!");
        }
    });

    // Regisztráció eseménykezelő
    registerForm?.addEventListener("submit", async (event) => {
        event.preventDefault();

        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        const response = await fetch("http://localhost:3000/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password })
        });

        const data = await response.text();
        alert(data);

        if (data.includes("Sikeres regisztráció")) {
            window.location.href = "login.html";
        }
    });

    // Kijelentkezési eseménykezelő
    window.logoutUser = function() {
        const token = localStorage.getItem("authToken");

        if (!token){
            alert("Nem vagy bejelentkezve! Kijelentkezés csak bejelentkezett felhasználóknak lehetséges.")
            return;
        }

        localStorage.removeItem("authToken");
        alert("Sikeres kijelentkezés!");
        window.location.href = "index.html";
    };

    // Navigáció frissítése bejelentkezés alapján
    const token = localStorage.getItem("authToken");
    const loginLink = document.getElementById("login-link");
    const registerLink = document.getElementById("register-link");
    const logoutLink = document.getElementById("logout-link");
    if (token) {
        loginLink.style.display = "none";
        registerLink.style.display = "none";
        logoutLink.style.display = "block";
    } else {
        loginLink.style.display = "block";
        registerLink.style.display = "block";
        logoutLink.style.display = "none";
    }

    // Foglalás gomb görgetése és foglalás indítása prompttal
    if (bookButton) {
        bookButton.addEventListener("click", () => {
            document.getElementById("booking").scrollIntoView({ behavior: "smooth" });
            if (selectedWeek) {
                bookWeek(parseInt(selectedWeek));
            }
        });
    }

    /* Lekérjük a lefoglalt heteket */
    async function fetchBookedWeeks() {
        const response = await fetch("http://localhost:3000/bookings");
        const data = await response.json();
        return data.map(booking => booking.week);
    }

    /* Foglalás kezelése */
    async function bookWeek(week, userId) {
        if (week < 1 || week > 52){
            alert("Hibás hét! Csak 1 és 52 közötti értékeket adhatsz meg.");
            return;
        }
        const response = await fetch("http://localhost:3000/book", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ week, userId })
        });

        const data = await response.text();
        alert(data);
        
        loadBookings(userId);
        loadUserProfile(userId);
    }

    // Regisztráció API hívás
    async function registerUser(name, email) {
        const response = await fetch("http://localhost:3000/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email })
        });
        const data = await response.text();
        alert(data);
    }

    // Bejelentkezés API hívás
    async function loginUser(email, password) {
        const response = await fetch("http://localhost:3000/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });
        const data = await response.json();
        if (data.token){
            localStorage.setItem("authToken", data.token);
            alert("Sikeres bejelentkezés!");
            window.location.reload();
        } else{
            alert("Hibás email vagy jelszó!");
        }
        function logoutUser(){
            localStorage.removeItem("authToken");
            alert("Sikeres kijelentkezés!");
            window.location.reload();
        }
    }

    /* A macskák kezelése: Betöltés, hozzáadás, törlés*/
    async function loadCats() {
        const response = await fetch("http://localhost:3000/cats");
        const data = await response.json();
    
        const container = document.getElementById("cats-container");
        if (!container) return;

        const isAdminPage = window.location.pathname.includes("admin.html");

        container.innerHTML = data.map(cat => `
            <div class="cat-card">
                <img src="${cat.image_url}" alt="${cat.name}">
                <h3>
                ${cat.name}
                <img src="${cat.gender === 'male' ? 'male-icon.png' : 'female-icon.png'}" alt="${cat.gender}" width="15">
                </h3>
                <p class="description">${cat.description}</p>
                ${isAdminPage ? `<button onclick="deleteCat(${cat.id})">Törlés</button>` : ""}
            </div>
        `).join("");
    }
    
    // Betöltés mindenek előtt
    document.addEventListener("DOMContentLoaded", () => {
        loadCats();
        loadFeaturedCat();
    });

    // Macska törlése
    window.deleteCat = async function(id) {
        const response = await fetch(`http://localhost:3000/cats/${id}`, {
            method: "DELETE"
        });
    
        const data = await response.text();
        alert(data);
        loadCats(); // Újratöltjük a listát
    }
    
    // Oldal indulásakor betöltjük a macskákat
    document.addEventListener("DOMContentLoaded", loadCats);

/* Foglalások betöltése */
async function loadBookings(userId) {
    const response = await fetch(`http://localhost:3000/bookings/${userId}`);
    if (!response.ok) {
        console.error("Hiba a foglalások betöltésekor!");
        return;
    }

    const data = await response.json();
    console.log("Foglalási adatok:", data);

    const bookingsList = document.getElementById("bookings-list");
    if (!bookingsList) return;

    bookingsList.innerHTML = data.length === 0 
        ? "<p>Nincsenek foglalásaid.</p>"
        : data.map(booking => `
            <p>Foglalás: Hét ${booking.week}</p>
        `).join("");
}

/* Felhasználói profil betöltése */
async function loadUserProfile(userId) {
    const response = await fetch(`http://localhost:3000/users/${userId}`);
    if (!response.ok) {
        console.error("Hiba a profil betöltésekor!");
        return;
    }

    const data = await response.json();
    console.log("Felhasználói profil adatok:", data); // Ellenőrzés

    const profileInfo = document.getElementById("profile-info");
    if (!profileInfo) return;

    profileInfo.innerHTML = `
        <h3>Üdvözöllek, ${data.name}</h3>
        <p>Email: ${data.email}</p>
    `;
}

    // Betöltjük a naptárt, macskákat, foglalásokat és profilt az oldal indulásakor
    if (weeksContainer) {
        renderCalendar();
    }

    if (catsContainer) {
        loadCats();
    }

    if (profileContainer) {
        loadUserProfile(userId);
    }
});
