-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2025 at 04:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cattalodge`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `week` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cats`
--

CREATE TABLE `cats` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `gender` enum('male','female') NOT NULL DEFAULT 'female'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cats`
--

INSERT INTO `cats` (`id`, `name`, `description`, `image_url`, `gender`) VALUES
(53, 'Mikróhullámos sütő', 'Ismerkedj meg Mikróval! Ő egy szelíd, idegenekkel jól kijövő kölyök cica, aki szereti azt, ha sokat simogatják és ha beleülhet az öledbe. Mint egy kis angyal, hosszas ideig elszórakoztatja a vendégeinket.', 'https://imgcdn.stablediffusionweb.com/2025/2/22/39634c8c-bfca-4c8f-a9c6-90fc15791bd6.jpg', 'male'),
(54, 'Vajas Herceg', 'Ismerkedj meg Hercegünkkel! Ahogy a név sugallja, egy nagyon kifinomult felnőtt cicáról van szó. Eleven és elegáns, sok ember szívét nyerte el a heti szavazás során.', 'https://d3pc1xvrcw35tl.cloudfront.net/images/1200x900/cat-animal-pet-1101_2025011373772.jpg', 'male'),
(56, 'Cirmos', 'Ismerkedj meg Cirmivel! Egy hiperaktív, barátságos cica. Nagyon szeret más cicákkal szocializálódni, és ugyan olyan szeretettel fordul vendégeink felé is. Sok vendégnek alig volt szíve egyedül hagyni.', 'https://catinaflat.blog/wp-content/uploads/2022/05/famous-tabby-cats.jpg', 'male'),
(57, 'Furrfru', 'Ismerkedj meg ezzel a FURRfangos egyeddel! Egy igazi arisztokrata macska, aki mindig tökéletesen ápolt bundában pózol. Fenséges megjelenése mögött egy kis csintalan lélek rejtőzik, aki imád vadászni a lakás legapróbb szöszére.', 'https://hips.hearstapps.com/hmg-prod/images/sacred-birma-cat-in-interior-royalty-free-image-1718202855.jpg?crop=0.672xw:1.00xh;0.163xw,0&resize=980:*', 'female'),
(58, 'Valentin', 'Ismerkedj meg Valentinnal! Egy igazi úriember, aki mindig előzékenyen figyel társára. Nyugodt, bölcs és minden helyzetben megőrzi a méltóságát. Ha lehetősége van rá, mindig a legkényelmesebb helyet választja pihenésre, és elegánsan figyeli a környezetét. Mély dorombolása szinte terápiás hatással van azokra, akik a közelében vannak. Narancshéj mellett érzi magát igazán otthon, és gondoskodó természetével mindig vigyáz rá.', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTs8Geqr2o9kgQlXuHVdDYJSjmNfi-iKoJJw&s', 'male'),
(59, 'Narancshéj', 'Ismerkedj meg Narival! Egy igazi kalandor, akinek nincs egy unalmas perce sem! Pörgős, kíváncsi, és minden új dolgot alaposan megvizsgál – legyen az egy új játék, egy frissen mosott takaró vagy egy furcsa hang a szomszéd szobában. Ha Valentin mellett van, sokszor képes megnyugodni, de egy pillanat alatt készen áll egy újabb játékra. Imád becserkészni, ugrándozni és vidám energiát hozni minden helyzetbe.', 'https://preview.redd.it/adopt-our-cute-little-orange-barn-cat-v0-engx7x8c4ptc1.jpeg?width=640&crop=smart&auto=webp&s=a525093a0ac965c967289e2bd25878648da3deee', 'female'),
(60, 'Megatron', 'Ismerkedj meg Megatronnal! Egy rettenthetetlen és határozott macska, aki úgy jár-kel a házban, mintha egy egész galaxis ura lenne. Szigorú tekintete mögött egy igazán ragaszkodó szív rejlik, és amikor nem épp világuralomra tör, szeret összekucorodni egy meleg takaró alatt.', 'https://miro.medium.com/v2/resize:fit:1400/1*VWTvBz3rO1ZdNIOI1DWk4w.jpeg', 'male'),
(61, 'Keksz', 'Ismerkedj meg Kekszikével! Az édes kis szőrpamacs, akinek mindig olyan az arckifejezése, mintha éppen egy finom falat után kutatna. Személyisége pont olyan, mint a neve – puha, meleg és mindenkit boldoggá tesz!', 'https://upload.wikimedia.org/wikipedia/commons/5/5d/Adult_Scottish_Fold.jpg', 'female'),
(62, 'Világpusztító', 'Ismerkedj meg Világpusztítóval! A neve ijesztően hangzik, de valójában csak egy nagy mókamester! Imád a magasban üldögélni és onnan vizslatni az alattvalóit (vagyis az embereket). Ha éppen nem egy csínytevésen töri a fejét, dorombolása világokat gyógyít.', 'https://i.pinimg.com/564x/0a/70/c9/0a70c906ed2bfdd5b370ef8d929dc4ee.jpg', 'male'),
(63, 'Fishron', 'Ismerkedj meg Fishronnal! Ez a cicus különleges kapcsolatban áll a vízzel – talán az egyetlen macska, aki érdeklődve nézi a csapból folyó vizet, és néha óvatosan bele is nyúl. Halacskás játékai nélkül nem telhet el egyetlen nap sem!', 'https://i.redd.it/v82wta66q5971.jpg', 'male'),
(64, 'Demogorgon', 'Ismerkedj meg Demoval! Egy kicsit rejtélyes és titokzatos lélek, aki imád az árnyékok között lapulni. Ha azt hiszed, egyedül vagy a szobában, Demogorgon hirtelen előbukkan egy sötét sarokból – de valójában csak egy kis simogatásra vágyik.', 'https://i.pinimg.com/236x/01/93/2f/01932f5885608eaceb23ff64d69fba92.jpg', 'female'),
(65, 'Cryogen', 'Ismerkedj meg Cryoval! Egy jeges szépség, akinek szemei olyanok, mint a téli égbolt. Szereti a hideg felületeken pihenni, és mindig higgadt marad – kivéve, ha egy tollas játék kerül elő, akkor azonnal vadászmódba kapcsol.', 'https://cdn.pixabay.com/photo/2018/04/20/17/18/cat-3336579_1280.jpg', 'male'),
(66, 'Bob', 'Ismerkedj meg Bobbal! Ő egy kis különc, aki maga dönti el, mikor van szüksége szeretetre. Ha ő úgy érzi, odajön hozzád egy kis törődésért, de ha te próbálnál kezdeményezni, gyorsan elillan, hogy megtartsa a maga kis távolságát. Különleges ízlésvilággal rendelkezik – imádja a zöldbabot, rajong a jégért, és a macskamenta az egyik nagy kedvence. Egy igazi kis titokzatos lélek, aki a maga módján szerethető.', 'https://files.catbox.moe/2s6opm.jpg', 'male'),
(67, 'Lucifer', 'Ismerkedj meg Luciferrel! Ő sokkal nyitottabb, mint Bob, de még mindig megválogatja, kinek adja oda a bizalmát. Ha sikerül elnyerned, egy különleges gesztussal viszonozza – imádja, ha az állát vakargatják. Ételek terén igazán kalandvágyó, a zöldbabot különösen kedveli, és szinte bármit megeszik, amit elé teszel próbaképp. Ő az a cica, aki mindig nyitott az új ízekre és élményekre, még ha maga a társasági lét néha kihívást jelent számára.', 'https://files.catbox.moe/pmcdyc.jpg', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(5, 'admin', 'admin@gmail.com', '$2b$10$99WWYMTuiKMzQDTd2rlitOaqFPj2ryLLcssSgDojGI.wIICmpkjzC'),
(7, 'sima felhasználó', 'user@gmail.com', '$2b$10$Oyrh69AgxCGxPKcBSWEjMOEgR/IqbPTUj0wEIqwrp5/uKvsSgGtxW');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `cats`
--
ALTER TABLE `cats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `cats`
--
ALTER TABLE `cats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
